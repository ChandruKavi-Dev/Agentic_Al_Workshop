from langgraph.graph import StateGraph, END
from typing import TypedDict
from agents.career_history_parser import career_history_parser
from agents.path_recommender import path_recommender
from agents.mentor_matcher import mentor_matcher
from agents.visualizer import path_visualizer

class MentorState(TypedDict):
    user_query: str
    parsed_data: dict
    recommendation: str
    mentors: list[str]
    tree: str

def build_graph():
    graph = StateGraph(state_schema=MentorState)
    graph.add_node("career_history_parser", career_history_parser)
    graph.add_node("path_recommender", path_recommender)
    graph.add_node("mentor_matcher", mentor_matcher)
    graph.add_node("visualizer", path_visualizer)

    graph.set_entry_point("career_history_parser")
    graph.add_edge("career_history_parser", "path_recommender")
    graph.add_edge("path_recommender", "mentor_matcher")
    graph.add_edge("mentor_matcher", "visualizer")
    graph.add_edge("visualizer", END)

    return graph.compile()
