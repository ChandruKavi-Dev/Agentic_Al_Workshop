# agents/tree_visualizer.py

from langchain_core.runnables import RunnableLambda
from mock_data.mock_data import mock_profiles

def get_tree(history):
    for key in mock_profiles:
        if key in history.lower():
            return mock_profiles[key]["career_tree"]
    return ["N/A"]

career_tree_visualizer = RunnableLambda(
    lambda state: {**state, "career_tree": get_tree(state.get("history", ""))}
)
