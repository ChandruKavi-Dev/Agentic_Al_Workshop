# agents/path_recommender.py

from langchain_core.runnables import RunnableLambda
from mock_data.mock_data import mock_profiles

def recommend_path(history):
    for key in mock_profiles:
        if key in history.lower():
            return mock_profiles[key]["recommendation"]
    return ["N/A"]

path_recommender = RunnableLambda(
    lambda state: {**state, "recommendation": recommend_path(state.get("history", ""))}
)
