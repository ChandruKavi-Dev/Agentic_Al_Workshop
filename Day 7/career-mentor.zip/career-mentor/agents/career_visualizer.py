from langchain_core.runnables import RunnableLambda
from mock_data.mock_data import mock_career_data

def generate_path_tree(history: str):
    interest = history.lower()
    for key in mock_career_data:
        if key in interest:
            return mock_career_data[key]["career_tree"]
    return ["N/A"]

career_path_visualizer = RunnableLambda(lambda state: {
    **state, 
    "career_path_tree": generate_path_tree(state.get("history", ""))
})
