# agents/career_history_parser.py

from langchain_core.runnables import RunnableLambda

def extract_history(state):
    user_input = state.get("user_query", "")
    return {**state, "history": f"Extracted history from: {user_input}"}

career_parser = RunnableLambda(extract_history)
