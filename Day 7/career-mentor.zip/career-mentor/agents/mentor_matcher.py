# agents/mentor_matcher.py

from langchain_core.runnables import RunnableLambda
from mock_data.mock_data import mock_profiles

def get_mentors_resources(history):
    for key in mock_profiles:
        if key in history.lower():
            return {
                "mentors": mock_profiles[key]["mentors"],
                "resources": mock_profiles[key]["resources"]
            }
    return {
        "mentors": ["N/A"],
        "resources": ["N/A"]
    }

mentor_matcher = RunnableLambda(
    lambda state: {
        **state,
        **get_mentors_resources(state.get("history", ""))
    }
)
