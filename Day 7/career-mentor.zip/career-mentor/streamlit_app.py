import streamlit as st
from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Union

from agents.career_history_parser import career_parser
from agents.path_recommender import path_recommender
from agents.mentor_matcher import mentor_matcher
from agents.visualizer import career_tree_visualizer



class State(TypedDict):
    user_query: str
    history: str
    recommendation: List[str]
    mentors: Union[List[str], List[dict]]
    resources: List[str]
    career_tree: List[str]

builder = StateGraph(State)



builder.add_node("parse", career_parser)
builder.add_node("recommend", path_recommender)
builder.add_node("mentor", mentor_matcher)
builder.add_node("tree", career_tree_visualizer)



builder.set_entry_point("parse")
builder.add_edge("parse", "recommend")
builder.add_edge("recommend", "mentor")
builder.add_edge("mentor", "tree")
builder.set_finish_point("tree")

graph = builder.compile()


st.set_page_config(page_title="Medical Career Path Mentor", layout="wide")
st.title("🧠 Medical Career Path Mentor")

st.markdown("""
Welcome to your AI-powered medical career advisor. Enter your background and interests below to receive personalized recommendations.
""")

with st.form("career_form"):
    col1, col2 = st.columns(2)

    with col1:
        education = st.text_input("🎓 Education Background", "MBBS")
        role = st.text_input("🏥 Current Role", "Junior Doctor")

    with col2:
        interest = st.text_input("🔍 Area of Interest", "Cardiology")

    submitted = st.form_submit_button("Get Career Path")

if submitted:
    input_text = f"Education: {education}, Role: {role}, Interest: {interest}"

    with st.spinner("Analyzing your profile..."):
        result = graph.invoke({"user_query": input_text})

    st.markdown("---")


    st.subheader("📋 Parsed Career History")
    st.success(result.get("history", "N/A"))


    st.subheader("🧭 Suggested Career Path")
    for step in result.get("recommendation", ["N/A"]):
        st.markdown(f"- {step}")

    col3, col4 = st.columns(2)

    with col3:
        st.subheader("👨‍🏫 Recommended Mentors")
        mentors = result.get("mentors", ["N/A"])
        if isinstance(mentors, list) and isinstance(mentors[0], dict):
            for m in mentors:
                st.markdown(f"**{m['name']}**  \n🩺 {m['specialty']}  \n📧 [{m['contact']}](mailto:{m['contact']})")
                st.markdown("---")
        else:
            st.write(mentors)

    with col4:
        st.subheader("📚 Learning Resources")
        for res in result.get("resources", ["N/A"]):
            st.markdown(f"📘 {res}")

    st.subheader("🌿 Career Path Tree")
    st.markdown("""
<style>
.tree-box {
    background-color: #f6f8fa;
    border-left: 4px solid #2c7be5;
    padding: 1em;
    margin-bottom: 1em;
    font-family: 'Courier New', monospace;
}
</style>
""", unsafe_allow_html=True)

    for step in result.get("career_tree", ["N/A"]):
        st.markdown(f"<div class='tree-box'>📌 {step}</div>", unsafe_allow_html=True)
