from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableLambda
from typing import TypedDict, List

# Define the data structure
class MentorState(TypedDict):
    user_query: str
    parsed_data: dict
    recommendation: List[str]
    mentor_info: List[str]
    tree_visual: str

# Mock agent functions
def parse_history(state):
    return {
        **state,
        "parsed_data": {
            "history": f"Extracted history from: {state['user_query']}"
        }
    }

def recommend_path(state):
    history = state["parsed_data"]["history"]
    return {
        **state,
        "recommendation": [
            f"Based on your history '{history}', we recommend exploring Cardiology or Internal Medicine."
        ]
    }

def get_mentor_info(state):
    return {
        **state,
        "mentor_info": [
            "👨‍⚕️ Dr. Alice - Cardiology Expert",
            "📘 Course: Cardiology 101 - AHA",
            "🔗 Webinar: Career in Internal Medicine"
        ]
    }

def generate_tree(state):
    return {
        **state,
        "tree_visual": f"📌 Tree View: Start ➜ {state['recommendation'][0]}"
    }

# Build the graph
def build_mock_graph():
    graph = StateGraph(state_schema=MentorState)

    graph.add_node("parse_history", RunnableLambda(parse_history))
    graph.add_node("recommend_path", RunnableLambda(recommend_path))
    graph.add_node("get_mentor_info", RunnableLambda(get_mentor_info))
    graph.add_node("generate_tree", RunnableLambda(generate_tree))

    graph.set_entry_point("parse_history")
    graph.add_edge("parse_history", "recommend_path")
    graph.add_edge("recommend_path", "get_mentor_info")
    graph.add_edge("get_mentor_info", "generate_tree")
    graph.add_edge("generate_tree", END)

    return graph.compile()
