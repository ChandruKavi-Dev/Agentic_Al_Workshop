# mock_data/mock_data.py

def create_mock_profile(specialty):
    return {
        "history": f"Education: MBBS, Role: Junior Doctor, Interest: {specialty}",
        "recommendation": [
            f"Step 1: Pursue specialization in {specialty}.",
            f"Step 2: Apply for government or private fellowships in {specialty}.",
            f"Step 3: Gain hands-on experience and sub-specialize if needed."
        ],
        "mentors": [
            {
                "name": f"Dr. {specialty} Mentor {i}",
                "specialty": f"{specialty} Expert",
                "contact": f"{specialty.lower()}mentor{i}@example.com"
            } for i in range(1, 4)
        ],
        "resources": [
            f"{specialty} Guidelines - WHO",
            f"Advanced {specialty} Masterclass - Coursera",
            f"{specialty} Journal Club - PubMed"
        ],
        "career_tree": [
            f"Start ➜ MBBS ➜ MS/MD in {specialty} ➜ Fellowship ➜ Consultant ➜ HOD"
        ]
    }

specialties = ["Cardiology", "Ophthalmology", "ENT", "Radiology", "Neurology", "Dermatology", "Pediatrics", "Oncology"]

mock_profiles = {specialty.lower(): create_mock_profile(specialty) for specialty in specialties}
