import streamlit as st
import google.generativeai as genai

# 🔐 Directly pass your Gemini API key here
genai.configure(api_key="AIzaSyDeLmTuK6pAQ5TTP7mYNM7fpXazmXJUTAs")

# Initialize Gemini model
model = genai.GenerativeModel(model_name="models/gemini-1.5-flash")

# Prompt template
def build_prompt(education, role, interests):
    return f"""
You are a helpful AI mentor for junior healthcare professionals.

User background:
- Education: {education}
- Current Role: {role}
- Interests: {interests}

Your task:
1. Recommend the best career paths based on inputs.
2. Suggest further study or specialization.
3. Mention 2 fictional mentors and their roles.
4. Visualize a career evolution tree in text.

Be clear, concise, and helpful.
"""

# AI response function
def get_recommendation(education, role, interests):
    prompt = build_prompt(education, role, interests)
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"❌ Error: {str(e)}"

# --- Streamlit UI ---
st.set_page_config(page_title="🩺 Career Path Mentor", layout="centered")
st.title("🩺 Medical Career Path Mentor")
st.markdown("Guide junior doctors to the best career path using Gemini AI!")

# Input form
with st.form("career_form"):
    education = st.text_input("🎓 Education", "MBBS")
    role = st.text_input("💼 Current Role", "Junior Doctor")
    interests = st.text_input("💡 Interests", "Public Health, Policy, Hospital Admin")

    submitted = st.form_submit_button("🔍 Get Recommendation")

# Output
if submitted:
    with st.spinner("Analyzing career paths..."):
        result = get_recommendation(education, role, interests)

    st.success("✅ Recommendation:")
    st.code(result, language="markdown")

    st.markdown("---")
    st.caption("Powered by Gemini 1.5 Flash | Built with Streamlit 🚀")
